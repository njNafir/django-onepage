from .views import ajax_two_act_handler, ajax_four_act_handler
